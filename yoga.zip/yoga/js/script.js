window.addEventListener('DOMContentLoaded', function(e){
	

	let infoHeaderTab = document.querySelectorAll('.info-header-tab'),
			infoTabContent= document.querySelectorAll('.info-tabcontent'),
			container			= document.querySelector('.container');

			

		function funcChikl (x, y){
			for(let i = y; i < x.length; i++){
				x[i].style.display = 'none';		
			}
		}

		function dotAvto (x, y){
			for(let i = y; i < x.length; i++){
				x[i].classList.remove('dot-active');		
			}
		}



funcChikl(infoTabContent, 1);


		function targetClick(){
		
			addEventListener('click', function(e){
	
				if(e.target.attributes.class.value === 'info-header-tab'){
						let index = +e.target.attributes.atr.value;
						funcChikl(infoTabContent, 0);
						infoTabContent[index].style = '';

				} 
			})

		}


	targetClick()





		let slider 				 = document.querySelector('.slider'),
				slider_element = document.querySelectorAll('.slider-item'),
				prev    			 = document.querySelector('.arrow-left'),
				go 						 = document.querySelector('.arrow-right'),
				next           = document.querySelector('.next'),
				bek 				   = document.querySelector('.prev'),
				i  						 = 0,
				dot = document.querySelectorAll('.dot');
	
				funcChikl(slider_element, 1);
				
			
			
				slider.addEventListener('click', function(e){

					if(e.target === go || e.target === next){
						slider_element[i].style.display = 'none';
						dot[i].classList.remove('dot-active');					
						i = (i + slider_element.length + 1) % slider_element.length;		
						slider_element[i].style.display = '';
						dot[i].classList.add('dot-active');
					 
						} 

				if(e.target === prev || e.target === bek){
						slider_element[i].style.display = 'none';
						dot[i].classList.remove('dot-active');
						i = (i + slider_element.length - 1) % slider_element.length;		
						slider_element[i].style.display = '';
						dot[i].classList.add('dot-active');
												
				}
				

					if(e.target.attributes.class.value === 'dot' || e.target.attributes.class.value === 'dot dot-active' || e.target.attributes.class.value === 'dot-active dot'){
						let index = +e.target.attributes.atr.value;
						 funcChikl(slider_element, 0);
						dotAvto(dot, 0);
						i = index;
						slider_element[index].style = '';
						dot[index].classList.add('dot-active');
						

				}

				})





				let dataTimer = `2019-06-18`;

        function dataTimerF(dataTimer){

         let t       = Date.parse(dataTimer) - Date.parse(new Date()),
             seconds = Math.floor((t/ 1000) % 60),
             min    =  Math.floor((t/ 1000/ 60) % 60),
             hors    = Math.floor((t/ 1000/ 60/ 60) % 60);

             if(t < 0){
             		return false; 
             }

             return {
                'total': t,
                'seconds': seconds,
                'min': min,
                'hors': hors
             }

        }


        function timer(dataTimer){

        let  hors     = document.querySelector('.hours'),
             min      = document.querySelector('.minutes'),
             seconds  = document.querySelector('.seconds'),
             tyme     = setInterval(funcTimer, 1000);

             

         function funcTimer(){
               let t =  dataTimerF(dataTimer);
               hors.innerText = t.hors,
               min.innerText = t.min,
               seconds.innerText = t.seconds;
               
               if(t.total < 0){
                clearInterval(tyme);
               } else if(t === false){
               	  clearInterval(tyme);
               	  hors.innerText = '00';
               	  min.innerText = '00';
                  seconds.innerText = '00';
               }

               if(+hors.innerText < 10 && +hors.innerText >= 0){
               		hors.innerText = '0' + t.hors;
               }

               if(+min.innerText < 10 && +min.innerText >= 0){
               		min.innerText = '0' + t.min;
               }

               if(+seconds.innerText < 10 && +seconds.innerText >= 0){
               		seconds.innerText = '0' + t.seconds;
               }

         }       

        }

        
        timer(dataTimer);



})

		


		

